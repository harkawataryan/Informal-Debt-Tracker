package com.jankydebt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DebtTrackerApplication {
    public static void main(String[] args) {
        // fingers crossed
        SpringApplication.run(DebtTrackerApplication.class, args);
    }
}
