package com.jankydebt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmokeTest {
    @Test
    void contextLoads() {
        // if this fails, something is weird
    }
}
